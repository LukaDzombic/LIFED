# kreiranje vektora pomocu QgsVectorFileWriter klase

# SaveVectorOptions sadrzi brojne funkcionalnosti
# za dati proces
lejer = QgsVectorLayer('point?crs=epsg:6316&field=id:integer', 'point', 'memory')
save_options = QgsVectorFileWriter.SaveVectorOptions()
transform_context = QgsProject.instance().transformContext()

# Pise u GeoPackage format (default)
error = QgsVectorFileWriter.writeAsVectorFormatV2(lejer,
"D:/Projekat/Project LIFED/Proba_gpkg",
transform_context,
save_options)

if error[0] == QgsVectorFileWriter.NoError:
    print('Uspesno kreiranje lejera.')
else:
    print('Error.')
    
# pise u shapefile formatu (UTF-8 encoding)
lejer_shp = QgsVectorLayer('polygon?crs=epsg:6316&field=id:integer', 'polygon', 'memory')
save_options.driverName = 'ESRI Shapefile'
save_options.fileEncoding = 'UTF-8'
error = QgsVectorFileWriter.writeAsVectorFormatV2(lejer_shp,
"D:/Projekat/Project LIFED/Proba_shp",
transform_context,
save_options)

if error[0] == QgsVectorFileWriter.NoError:
    print('Uspesno kreiranje lejera.')
else:
    print('Error.')
    






