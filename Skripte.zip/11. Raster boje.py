raster = QgsProject.instance().mapLayersByName('DEM Doljevac')[0]

# postavljanje upita za trenutni renderer
print(raster.renderer())
# vraca tip rastera
print(raster.renderer().type())

# menjanje boje (rendera) za rastere sa jednim kanalom
# kreiranje skale (objekat QgsColorRampShader)
skala = QgsColorRampShader()
# biranje tipa skale
skala.setColorRampType(QgsColorRampShader.Interpolated)
# kreiranje boja koje ce se koristiti (Narandzasta i Zuta)
lista = [QgsColorRampShader.ColorRampItem(0, QColor(225,0,0)),
QgsColorRampShader.ColorRampItem(255, QColor(225,225,0))]
# dodavanje boja skali
skala.setColorRampItemList(lista)
shader = QgsRasterShader()
shader.setRasterShaderFunction(skala)

# povezivanje shader-a sa rasterom
# broj 1 ukazuje broj kanala
renderer = QgsSingleBandPseudoColorRenderer(raster.dataProvider(), 1, shader)
raster.setRenderer(renderer)
raster.triggerRepaint()








