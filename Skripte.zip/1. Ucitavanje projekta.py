# Skriptu je potrebno importovati ukoliko se pokrece izvan QGIS-a
# Klase koje ce se koristiti su qgis i PyQT
# from qgis.core import QgsProject

# Instanciranje projekta
project = QgsProject.instance()

# Ucitavanje projekta
project.read('D:/Projekat/Project LIFED/Projekat Lifed.qgz')

# Cuvanje projkta sa istim imenom
project.write()
# Cuvanje projekta sa razlicitim imenom
project.write('D:/Projekat/Project LIFED/Projekat Lifed/Podaci_QGIS/Drugi_naziv.qgz')

# Menja lose "putanje", u slucaju da doslo do promene lokacije lejera, promene adrese od hosta baze podataka..
'''def my_processor(path):
    return path.replace('host=10.1.1.115', 'host=10.1.1.116')

QgsPathResolver.setPathPreprocessor(my_processor)'''
