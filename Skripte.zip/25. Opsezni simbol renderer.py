from qgis.PyQt import QtGui


# korisceni lejer: Gradovi
lejer = iface.activeLayer()
atribut = 'nm_visina'
opseg = []
prozirnost = 1
# kreira se prvi simbol i opseg
min = 1000
max = 2000
naziv = '1000-2000'
boja = QtGui.QColor('#ff7d7d')
prvi_simbol = QgsSymbol.defaultSymbol(lejer.geometryType())
prvi_simbol.setColor(boja)
prvi_simbol.setOpacity(prozirnost)
prvi_opseg = QgsRendererRange(min, max, prvi_simbol, naziv)
opseg.append(prvi_opseg)
# drugi simbol
min = 2000
max = 4000
naziv = '2000-4000'
boja = QtGui.QColor('#fc0303')
drugi_simbol = QgsSymbol.defaultSymbol(lejer.geometryType())
drugi_simbol.setColor(boja)
drugi_simbol.setOpacity(prozirnost)
drugi_opseg = QgsRendererRange(min, max, drugi_simbol, naziv)
opseg.append(drugi_opseg)

renderer = QgsGraduatedSymbolRenderer('', opseg)
metod_klasifikacije = QgsApplication.classificationMethodRegistry().method('EqualInterval')
renderer.setClassificationMethod(metod_klasifikacije)
renderer.setClassAttribute(atribut)

lejer.setRenderer(renderer)
lejer.triggerRepaint()











