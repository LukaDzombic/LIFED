'''from qgis.PyQt.QtGui import (
    QColor,
)

from qgis.PyQt.QtCore import Qt, QRectF

from qgis.core import (
    QgsVectorLayer,
    QgsPoint,
    QgsPointXY,
    QgsProject,
    QgsGeometry,
    QgsMapRendererJob,
)

from qgis.gui import (
    QgsMapCanvas,
    QgsVertexMarker,
    QgsMapCanvasItem,
    QgsRubberBand,
)''' # ukoliko je standalone


canvas = QgsMapCanvas()
canvas.show()

canvas.setCanvasColor(Qt.blue)
canvas.enableAntiAliasing(True)

# korisceni lejer = CLC Doljevac
lejer = iface.activeLayer()

if not lejer.isValid():
    print('Lejer nije uspesno ucitan')

# namesta obim po ucitanom lejeru
canvas.setExtent(lejer.extent())

# podesava lejere za "platno" mape
canvas.setLayers([lejer])

linije = QgsRubberBand(canvas, False) # False oznacava da nije poligon
tacke = [
QgsPoint(7570384,4791743), 
QgsPoint(7572848,4789930), 
QgsPoint(7570231,4789651)
]
linije.setToGeometry(QgsGeometry.fromPolyline(tacke), None)
linije.setWidth(3)
linije.setColor(QColor(255,255,255))

poligon = QgsRubberBand(canvas, True) # True oznacava da je u pitanju poligon
tacke = [
[QgsPointXY(7570384,4791743), 
QgsPointXY(7572662,4791325), 
QgsPointXY(7572848,4789930), 
QgsPointXY(7570231,4789651)]
]
poligon.setToGeometry(QgsGeometry.fromPolygonXY(tacke), None)
poligon.setColor(QColor(255,0,0))

# ukoliko zelimo da "sakrijemo" odredjeni item
#poligon.hide()

# ukoliko zelimo da prikazemo odredjeni item
#poligon.show()

# ukoliko zelimo da uklonimo lejer iz scene
#canvas.scene().removeItem(tacke)


m = QgsVertexMarker(canvas)
m.setCenter(QgsPointXY(7567041,4786615))

m.setColor(QColor(50,50,200))
m.setIconSize(7)
m.setIconType(QgsVertexMarker.ICON_CIRCLE)
m.setPenWidth(4)








