# korisceni lejer = CLC Doljevac

lejer = QgsProject.instance().mapLayersByName('CLC Doljevac')[0]
# moze i preko iface.activeLayer()

# filtrira stene kojima skacenica pocinje sa 'T',
# zatim izvlaci njihove feature-e
upit = '"code_18" LIKE \'T%\''
features = lejer.getFeatures(QgsFeatureRequest().setFilterExpression(upit))

# vrsi iteraciju nad feature-ima, i izvrsava 
# geometrijsku komputaciju i stampa rezultate
for f in features:
    geom = f.geometry()
    naziv = f.attribute('OpisStari')
    print(naziv)
    print('Povrsina (km_2): ', geom.area()/1000000)
    print('Duzina (km): ', geom.length()/1000)
    

# alternativni nacin
# stampa kod od elipsoida koji se koristi
# print(QgsProject.instance().ellipsoid())
# stampa sve elipsoide po njihovom kodu
# print(QgsEllipsoidUtils.acronyms())
'''d = QgsDistanceArea()
d.setEllipsoid('EPSG:6316')

for f in features:
    geom = f.geometry()
    naziv = f.attribute('OpisStari')
    print(naziv)
    print('Duzina (km): ', d.measurePerimeter(geom)/1000)
    print('Povrsina (km_2): ', d.measureArea(geom)/1000000)'''

    
    