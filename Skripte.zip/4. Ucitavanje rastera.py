import os

# Ucitavanje rastera u projekat


# Putanja do rastera (TIF)
put_do_dema = 'D:/Fakultet/Master/Upravljanje_GIS_projektima/Projekat_PLUSLO/Podaci_QGIS/DEM_Loznica.tif'

rlayer = QgsRasterLayer(put_do_dema, 'DEM')

if not rlayer.isValid():
    print('Lejer nije uspesno ucitan.')
else:
    QgsProject.instance().addMapLayer(rlayer)

# Drugi nacin
# iface.addRasterLayer(put_do_dema, 'DEM')
