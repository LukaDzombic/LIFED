# koriscenje prostornih indeksa
# vise o njima na https://postgis.net/workshops/postgis-intro/indexing.html

# korisceni lejer = CLC Doljevac
lejer = iface.activeLayer()
feat = QgsFeature(lejer.fields())


# instanciranje objekta QgsSpatialIndex
indeks = QgsSpatialIndex(lejer.getFeatures())
# drugi nacin
# index = QgsSpatialIndex()
# index.addFeature(feat)


# vraca listu sa FID-ovima 5 najblizih feature-a
najblizi = indeks.nearestNeighbor(QgsPointXY(7567041,4786615), 5)
print(najblizi)

# vraca listu FID-ova od feature-a koji seku dati pravougaonik
intersect = indeks.intersects(QgsRectangle(7566973,4787722, 7571020,4784260))
print(intersect)

