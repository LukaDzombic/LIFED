'''from qgis.core import (
  QgsGeometry,
  QgsPoint,
  QgsPointXY,
  QgsWkbTypes,
  QgsProject,
  QgsFeatureRequest,
  QgsVectorLayer,
  QgsDistanceArea,
  QgsUnitTypes,
  QgsCoordinateTransform,
  QgsCoordinateReferenceSystem
)''' 

# kreiranje geometrije iz koordinata
Tacka = QgsGeometry.fromPointXY(QgsPointXY(7565921,4787559))
print(Tacka)
Linija = QgsGeometry.fromPolyline([QgsPoint(7566060,4785607), QgsPoint(7570802,4787373)])
print(Linija)
Poligon = QgsGeometry.fromPolygonXY([
[QgsPointXY(7570384,4791743), 
QgsPointXY(7572662,4791325),
QgsPointXY(77572848,4789930),
QgsPointXY(7570291,4789651)]
])
print(Poligon)

# WKT - well-known text format (vise na https://en.wikipedia.org/wiki/Well-known_text_representation_of_geometry)
geom_iz_wkt = QgsGeometry.fromWkt('POINT(7571020,4784260)')
print(geom_iz_wkt)



