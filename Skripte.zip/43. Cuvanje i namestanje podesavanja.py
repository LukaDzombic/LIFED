'''from qgis.core import (
  QgsProject,
  QgsSettings,
  QgsVectorLayer
)'''             # ukoliko je standaloneDayName

# cuva podesavanja na globalnom nivou (vezano za korisnika koji koristi kompjuter)

s = QgsSettings()
#print(s.allKeys())

def sacuvaj():
    s = QgsSettings()
    s.setValue("mojplugin/mojtekst", "Upravljanje Projektima")
    s.setValue("mojplugin/mojcelobrojni",  8)
    s.setValue("mojplugin/mojrealni", 2.04)
    
def procitaj():
    s = QgsSettings()
    mojtekst = s.value("mojplugin/mojtekst", "Upravljanje Projektima")
    mojcelobrojni  = s.value("mojplugin/moj_elobrojni", 8)
    mojrealni = s.value("mojplugin/mojrealni", 2.04)
    print(mojtekst)
    print(mojcelobrojni)
    print(mojrealni)
    
sacuvaj()
procitaj()


projekat = QgsProject.instance()

# cuva vrednosti
projekat.writeEntry("mojplugin", "mojtekst", "Upravljanje Projektima")
projekat.writeEntry("mojplugin", "mojcelobrojni", 8)
projekat.writeEntryDouble("mojplugin", "mojrealni", 2.04)
projekat.writeEntryBool("mojplugin", "bulovaalgebra", True)

# cita vrednosti (vraca torku sa vrednostima, i Bulov status
# koji govori da li se vracena vrednost moze konvertovati u njen tip,
# odnosno iz stringa, celobrojnog broja, realnog broja i Bulovog izraza

moj_tekst, type_conversion_ok = projekat.readEntry("mojplugin", "mojtekst", "Upravljanje Projektima")
moj_celobrojni, type_conversion_ok = projekat.readNumEntry("mojplugin", "mojcelobrojni", 8)
moj_realni, type_conversion_ok = projekat.readDoubleEntry("mojplugin", "mojrealni", 2.04)
moja_bulova_algebra, type_conversion_ok = projekat.readBoolEntry("mojplugin", "bulova_algebra", True)

lejer = QgsProject.instance().mapLayersByName("Gradovi")[0]
# cuva vrednost za odredjeni lejer
lejer.setCustomProperty('mojtekst', 'Gradovi na opstini Doljevac')
# ponovo cita vrednost; drugi argument vraca 
tekst = lejer.customProperty('mojtekst', 'nemateksta')


print(tekst)







  