
# priprema QgsFeature objekat da bude dodat lejeru
# zadrzavajuci sva ogranicenja i default vrednosti
# korisceni atribut Reke Doljevac
lejer = iface.activeLayer()
feat = QgsVectorLayerUtils.createFeature(lejer)


# getValues metod omogucava dobijanje vrednosti
# za odredjeni atribut ili izraz
lejer.selectByIds([1])
value = QgsVectorLayerUtils.getValues(lejer, 'Opstine', selectedOnly=True)
print(value)