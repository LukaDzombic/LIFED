import time
'''from qgis.PyQt.QtWidgets import QProgressBar
from qgis.PyQt.QtCore import *'''


napredakPoruka = iface.messageBar().createMessage('Uploading...')
napredak = QProgressBar()
napredak.setMaximum(5)
napredak.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
napredakPoruka.layout().addWidget(napredak)
iface.messageBar().pushWidget(napredakPoruka, Qgis.Info)

for i in range(7):
    time.sleep(1)
    napredak.setValue(i + 1)

# iface.messageBar().clearWidgets()


lejer = QgsProject.instance().mapLayersByName('CLC Doljevac')[0]

count = lejer.featureCount()
features = lejer.getFeatures()

for i, feature in enumerate(features):
    print(i)
    procenat = i / float(count) * 100
    
    iface.mainWindow().statusBar().showMessage('Obradjeno {}%'.format(int(procenat)))
    iface.statusBarIface().showMessage('Obradjeno {}%'.format(int(procenat)))

# ukoliko zelimo da obrisemo poruku
#iface.statusBarIface().clearMessage()