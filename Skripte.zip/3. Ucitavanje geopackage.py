import os

# Ucitavanje rastera u projekat


# Putanja do rastera (TIF)
put_do_dema = 'D:/Projekat/Project LIFED/DEM Doljevac.tif'

rlayer = QgsRasterLayer(put_do_dema, 'DEM')

if not rlayer.isValid():
    print('Lejer nije uspesno ucitan.')
else:
    QgsProject.instance().addMapLayer(rlayer)

# Drugi nacin
# iface.addRasterLayer(put_do_dema, 'DEM')
