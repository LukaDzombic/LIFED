root = QgsProject.instance().layerTreeRoot()

Gradovi = QgsProject.instance().mapLayersByName('Gradovi')[0]

# kreira "privremeni" lejer
layer1 = QgsVectorLayer('D:/Projekat/Project LIFED/priv_lejer', 'privremeni', 'memory')
# dodaje lejer na poslednju poziciju u legendi
root.addLayer(layer1)
# dodaje lejer na specificno navedenu poziciju
#root.insertLayer(3, layer1)

# Takodje moguce je dodati lejer u registar lejera mape
# QgsProject.instance()addMapLayer(layer1)

node_layer = root.findLayer(Gradovi.id())
print('Cvor lejera: ', node_layer)
print('Lejer na mapi: ', node_layer.layer())

# dodavanje grupa
node_group1 = root.addGroup('Nova Grupa')
# dodaje podgrupu prethodno kreiranoj grupi
node_subgroup1 = node_group1.addGroup('Nova Podgrupa')

# Prebacivanje cvorova i grupa
# prvo se klonira postojeci cvor
cloned_group1 = node_group1.clone()
# zatim se pomera cvor (ujedno se pomeraju i lejeri i podgrupe)na vrh
root.insertChildNode(0, cloned_group1)
# uklanjanje originalnog cvora
root.removeChildNode(node_group1)