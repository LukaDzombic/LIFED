# from qgis.PyQt5.QtCore import QVariant - ukoliko je standalone

# definise atribute za feature-e. Neophodno istancirati QgsFields()
atributi = QgsFields()
atributi.append(QgsField('Jedan', QVariant.Int))
atributi.append(QgsField('Dva', QVariant.String))

# kreira instancu vektor file writer-a , koji ce kreirati vektorski fajl

# uzima koordinatni sistem projekta
crs = QgsProject.instance().crs()
transform_context = QgsProject().instance().transformContext()
save_options = QgsVectorFileWriter.SaveVectorOptions()
save_options.driverName = 'ESRI Shapefile'
save_options.fileEncoding = 'UTF-8'

writer = QgsVectorFileWriter.create(
'D:/Projekat/Project LIFED/Proba_shp_2',
atributi,
QgsWkbTypes.Point,
crs,
transform_context,
save_options
)

if writer.hasError() != QgsVectorFileWriter.NoError:
    print('Greska pri kreiranju SHP_Fajla: ', writer.errorMessage())
    
# dodaje feature
feat = QgsFeature()

feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(7368547,4947057)))
feat.setAttributes([1, 'visina'])
writer.addFeature(feat)


# brise se writer kako bi se izbacili feature-i na disk
del writer






