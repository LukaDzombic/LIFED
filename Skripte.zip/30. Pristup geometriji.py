'''from qgis.core import (
  QgsGeometry,
  QgsPoint,
  QgsPointXY,
  QgsWkbTypes,
  QgsProject,
  QgsFeatureRequest,
  QgsVectorLayer,
  QgsDistanceArea,
  QgsUnitTypes,
  QgsCoordinateTransform,
  QgsCoordinateReferenceSystem
)''' 

# kreiranje geometrije iz koordinata
Tacka = QgsGeometry.fromPointXY(QgsPointXY(7565921,47875597))
#print(Tacka)
Linija = QgsGeometry.fromPolyline([QgsPoint(7566060,4785607), QgsPoint(7570802,4787373)])
#print(Linija)
Poligon = QgsGeometry.fromPolygonXY([
[QgsPointXY(7570384,4791743), 
QgsPointXY(7572662,4791325),
QgsPointXY(77572848,4789930),
QgsPointXY(7570291,4789651)]
])
#print(Poligon)

# proverava tip geometrije
if Tacka.wkbType() == QgsWkbTypes.Point:
    print(Tacka.wkbType())
    # izlaz: 1 za tacku
if Linija.wkbType() == QgsWkbTypes.LineString:
    print(Linija.wkbType())
    # izlaz: 2 za liniju
if Poligon.wkbType() == QgsWkbTypes.Polygon:
    print(Poligon.wkbType())
    # izlaz: 3 za poligon


# alternativni nacin
print(QgsWkbTypes.displayString(Tacka.wkbType()))
# izlaz: Point
print(QgsWkbTypes.displayString(Linija.wkbType()))
# izlaz: LineString
print(QgsWkbTypes.displayString(Poligon.wkbType()))


# proverava da li je geometrija sastavljena iz vise delova ili ne
# vise o tome na https://sspinnovations.com/blog/lesser-known-gis-feature-types-multipoint-multipatch-dimension/
print(Tacka.isMultipart())


# metode za pristup svakom vektorskom tipu torke predstavljanje
# u vidu XY koordinata nisu prave torke vec QgsPoint objekti, cijim
# vrednostima se moze pristupiti pomocu x() i y() metodama
print(Tacka.asPoint())
print(Linija.asPolyline())
print(Poligon.asPolygon())
# za multipart geometrije to su: asMultiPoint(), asMultiPolyline(), asMultiPolygon()


# vrsi iteraciju nad svim delovima geometrije
for deo in Poligon.parts():
    print(deo.asWkt())

# vrsi transformaciju svakog dela geometrije
for deo in Tacka.parts():
    deo.transform(QgsCoordinateTransform(
    QgsCoordinateReferenceSystem('EPSG:6316'),
    QgsCoordinateReferenceSystem('EPSG:32634'),
    QgsProject.instance())
    )
print(Tacka.asWkt())














