# Potrebno obeleziti lejer u legendi, mora da bude vektor
# Korisceni lejer: CLC Doljevac
lejer = iface.activeLayer()
# Selektuje sve feature od lejera
# lejer.selectAll()

# Selektuje feature-e na osnovu odredjenog izraza
# Razlikuje se od lejera na kom se koristi (u ovom slucaju CLC Doljevac)
# prvi argument predstavlja izraz, na osnovu kog se vrsi upit
lejer.selectByExpression('"Code_18" > 200 and "povrsina" > 1.0', QgsVectorLayer.SetSelection)

# menja boju selekcije (default je Plava)
iface.mapCanvas().setSelectionColor(QColor('blue'))

# brise selektovane feature
# lejer.removeSelection()

#selected_fid = []

# uzima prvi feature id iz lejera
'''for feature in lejer.getFeatures():
    selected_fid.append(feature.id())
    break'''

# dodaje ove feature selektovanoj listi
# lejer.select(selected_fid)

# lejer.removeSelection()

# atributima se moze pristupiti na osnovu imena ili indeksa
#print(feature['povrsina'])
#print(feature[1])

# ukoliko su nam potrebni samo selektovani feature-i
selekcija = lejer.selectedFeatures()
for feature in selekcija:
    if feature['povrsina'] < 1.0:
        print('Povrsina je manja od 1km kvadratni')
    else:
        print('Povrsina je veca od 1km kvadratni')




















