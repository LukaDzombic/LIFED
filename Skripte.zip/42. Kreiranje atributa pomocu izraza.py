#from qgis.PyQt.QtCore import QVariant     # ukoliko je standalone


lejer = QgsVectorLayer('Point?crs=epsg:6316', 'Doljevac', 'memory')
pr = lejer.dataProvider()
pr.addAttributes(
[QgsField('naziv', QVariant.String),
QgsField('br_stanovnika', QVariant.Int),
QgsField('nm_visina', QVariant.Int),
QgsField('Bafer', QVariant.Int)]
)

podaci = [
{'x': 7568199, 'y':4784212, 'ime': 'Doljevac', 'stanovnici': 18850, 'visina': 250},
]

for podatak in podaci:
    f = QgsFeature()
    tacka = QgsPointXY(podatak['x'], podatak['y'])
    f.setGeometry(QgsGeometry.fromPointXY(tacka))
    f.setAttributes([podatak['ime'], podatak['stanovnici'], podatak['visina']])
    pr.addFeature(f)

lejer.updateExtents()
QgsProject.instance().addMapLayer(lejer)

# prvi izraz racuna ukupan broj stanovnika
# drugi izraz kreira bafer zonu oko tacaka, na osnovu 
# nadmorske visine a zatim racuna povrsinu te bafer zone
izraz1 = QgsExpression('sum("br_stanovnika")')
izraz2 = QgsExpression('area(buffer($geometry, "nm_visina"))')


# QgsExpressionContextUtils.globalProjectLayerScopes() je funkcija koja nam pomaze
# da dodamo globalni obim (scope), projekat, i lejere (unutar tog obima) u isto vreme
# Uvek se krece od najopstijeg
# do najspecificnijeg obima (npr. od gobalnog, ka projektu, ka lejerima)
# vise o obimu na https://realpython.com/python-namespaces-scope/
context = QgsExpressionContext()
context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(lejer))

with edit(lejer):
    for f in lejer.getFeatures():
        context.setFeature(f)
        f['nm_visina'] = izraz1.evaluate(context)
        f['Bafer'] = izraz2.evaluate(context)
        lejer.updateFeature(f)

print(f['ukupni_stan'])
print(f['Bafer'])








