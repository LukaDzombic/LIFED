root = QgsProject.instance().layerTreeRoot()
Gradovi = QgsProject.instance().mapLayersByName('Gradovi_Doljevac')[0]


# pomeranje lejera u legendi
# kreiranje objekta QgsLayerTreeLayer iz Gradovi po njegovom ID-u
Gradovivektor = root.findLayer(Gradovi.id())
# klonira se prethodno kreirani objekat
Gradovivektorklon = Gradovivektor.clone()
# uzima "roditelja". Ukoliko je rezultat None,
# znaci da lejer nije ni u jednog grupi i vratice ''
roditelj = Gradovivektor.parent()
# pomera se klonirani lejer na vrh
roditelj.insertChildNode(0, Gradovivektorklon)
# uklanja se originalni lejer (Gradovivektor)
root.removeChildNode(Gradovivektor)

# prebacivanje lejera u odredjenu grupu (slican postupak kao kod pomeranja)
Gradovivektor = root.findLayer(Gradovi.id())
Gradovivektorklon = Gradovivektor.clone()
# kreiranje nove grupe
grupa1 = root.addGroup('Nova Grupa')
roditelj = Gradovivektor.parent()
grupa1.insertChildNode(0, Gradovivektorklon)
roditelj.removeChildNode(Gradovivektor)

# jos neke metode, koje mogu da se koriste za menjanje
# grupa i lejera

# menjanje imena grupe
# node_group1.setName('Doljevac')

# menjanje naziva lejera
#node_layer2 = root.findLayer(Gradovi.id())
#print(node_layer2.name())
#node_layer2.setName('Doljevac')
#print(node_layer2.name())

# ukljucivanje i iskljucivanje lejera
#node_group1.setItemVisibilityChecked(True)
#node_layer2.setItemVisibilityChecked(False)

# prosiruje i sakriva grupe u legendi
#node_group1.setExpanded(True)
#node_group1.SetExpanded(False)










