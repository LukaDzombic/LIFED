# korisceni lejer Gradovi
lejer = iface.activeLayer()

kategorizovani_renderer = QgsCategorizedSymbolRenderer()
# Dodaje par kategorija
kategorija1 = QgsRendererCategory('1', QgsMarkerSymbol(), 'kat 1')
kategorija2 = QgsRendererCategory('2', QgsMarkerSymbol(), 'kat 2')
kategorija3 = QgsRendererCategory('3', QgsMarkerSymbol(), 'kat 3')

# kreiranje simbola za svaku kategoriju
simbol_1 = QgsMarkerSymbol.createSimple({'name': 'diamond', 'color': 'green'})
kat1.setSymbol(simbol_1)

simbol_2 = QgsMarkerSymbol.createSimple({'name': 'square', 'color': 'yellow'})
kat2.setSymbol(simbol_2)

simbol_3 = QgsMarkerSymbol.createSimple({'name': 'triangle', 'color': 'red'})
kat3.setSymbol(simbol_3)

# dodavanje kategorija rendereru
kategorizovani_renderer.addCategory(kategorija1)
kategorizovani_renderer.addCategory(kategorija2)
kategorizovani_renderer.addCategory(kategorija3)

for kat in kategorizovani_renderer.categories():
    print('{}: {} :: {}'.format(kat.value(), kat.label(), kat.symbol()))

kategorizovani_renderer.setClassAttribute('kategorije')
lejer.setRenderer(kategorizovani_renderer)
lejer.triggerRepaint()