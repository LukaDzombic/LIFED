import os #potrebno i u QGIS-u
# from qgis.core import (QgsVectorLayer) - potrebno u standalone

# Povlaci lejer na toj lokaciji
putanja_do_Corine = 'D:/Projekat/Project LIFED/CLC Doljevac.shp'

# Format je:
# vlayer = QgsVectorLayer(data_source, layer_name, provider_name)
vlayer = QgsVectorLayer(putanja_do_Corine, 'CLC Doljevac', 'ogr')

# Proverava da li je lejer uspesno ucitan
if not vlayer.isValid():
    print('Lejer nije uspesno ucitan')
else:
    QgsProject.instance().addMapLayer(vlayer)
